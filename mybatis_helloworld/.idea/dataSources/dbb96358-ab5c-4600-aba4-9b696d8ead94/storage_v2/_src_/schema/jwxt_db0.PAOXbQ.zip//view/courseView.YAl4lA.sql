create view courseView as
select `jwxt_db0`.`course`.`courseTypeNo` AS `课程类型编号`,
       `jwxt_db0`.`course`.`courseNo`     AS `课程编号`,
       `jwxt_db0`.`course`.`courseName`   AS `课程名称`,
       `jwxt_db0`.`course`.`credit`       AS `学分`,
       `jwxt_db0`.`course`.`ctime`        AS `课时`,
       `jwxt_db0`.`course`.`openTeam`     AS `开课组织`,
       `jwxt_db0`.`course`.`isRequire`    AS `是否必修`,
       `jwxt_db0`.`course`.`deptNo`       AS `部门编号`,
       `jwxt_db0`.`course`.`remark`       AS `评论`
from `jwxt_db0`.`course`;

