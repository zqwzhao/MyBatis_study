create view studentScoreView as
select `stu`.`studentNo` AS `学号`, `stu`.`studentName` AS `姓名`, `co`.`courseName` AS `课程名`, `sc`.`endScore` AS `总评分`
from ((`jwxt_db0`.`student` `stu` join `jwxt_db0`.`score` `sc` on ((`stu`.`studentNo` = `sc`.`studentNo`)))
         join `jwxt_db0`.`course` `co` on ((`sc`.`courseNo` = `co`.`courseNo`)));

