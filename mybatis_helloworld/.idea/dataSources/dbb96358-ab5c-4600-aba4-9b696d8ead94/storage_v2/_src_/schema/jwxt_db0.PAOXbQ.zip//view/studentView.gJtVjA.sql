create view studentView as
select `jwxt_db0`.`student`.`studentNo`   AS `学号`,
       `jwxt_db0`.`student`.`studentName` AS `姓名`,
       `jwxt_db0`.`student`.`sex`         AS `性别`,
       `jwxt_db0`.`student`.`birthday`    AS `出生日期`,
       `jwxt_db0`.`student`.`classNo`     AS `班级编号`
from `jwxt_db0`.`student`;

