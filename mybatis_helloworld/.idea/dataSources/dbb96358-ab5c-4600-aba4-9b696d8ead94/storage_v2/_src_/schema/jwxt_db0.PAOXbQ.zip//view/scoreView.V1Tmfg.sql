create view scoreView as
select `jwxt_db0`.`score`.`teamNo`         AS `团队编号`,
       `jwxt_db0`.`score`.`studentNo`      AS `学号`,
       `jwxt_db0`.`score`.`courseNo`       AS `课程编号`,
       `jwxt_db0`.`score`.`peacetimeScore` AS `平时分数`,
       `jwxt_db0`.`score`.`prriodScore`    AS `期末分数`,
       `jwxt_db0`.`score`.`endScore`       AS `最终分数`
from `jwxt_db0`.`score`;

